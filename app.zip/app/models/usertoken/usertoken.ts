
export class UserToken {
    access_token: string;
token_type: string;
userName: string;
  
}
 

export class RegisterResponse
    {
          code :string;
          status :string;
          emaidId:string; 
          id :string;

          roomId :string;
    }